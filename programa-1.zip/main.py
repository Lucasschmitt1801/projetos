
numero1 = int(input("Digite o primeiro número inteiro: "))
numero2 = int(input("Digite o segundo número inteiro: "))
numero3 = int(input("Digite o terceiro número inteiro: "))


menor_numero = min(numero1, numero2, numero3)

print("O menor número é:", menor_numero)
